import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';
import ThemeToggle from './ThemeToggle';
import ThemeToggle from './ThemeToggle';

const Header = () => {
  return (
    <header className="bg-white dark:bg-gray-900 shadow-lg sticky top-0 z-50 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-r from-gray-700 to-gray-900 rounded-lg flex items-center justify-center transform hover:scale-110 transition-transform duration-300">
              <span className="text-white font-bold text-xl">MG</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white transition-colors duration-300">Premium Stone Co.</h1>
              <p className="text-sm text-gray-600 dark:text-gray-300 transition-colors duration-300">Marble & Granite Specialists</p>
            </div>
          </div>
          
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#home" className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white font-medium transition-all duration-300 hover:scale-105">Home</a>
            <a href="#products" className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white font-medium transition-all duration-300 hover:scale-105">Products</a>
            <a href="#services" className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white font-medium transition-all duration-300 hover:scale-105">Services</a>
            <a href="#about" className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white font-medium transition-all duration-300 hover:scale-105">About</a>
            <a href="#contact" className="bg-gradient-to-r from-gray-700 to-gray-900 dark:from-yellow-400 dark:to-orange-500 text-white dark:text-gray-900 px-6 py-2 rounded-lg hover:from-gray-800 hover:to-black dark:hover:from-yellow-500 dark:hover:to-orange-600 transition-all duration-300 transform hover:scale-105">
              Get Quote
            </a>
          </nav>

          <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-300">
            <ThemeToggle />
            <ThemeToggle />
            <div className="hidden lg:flex items-center space-x-1">
              <Phone size={16} />
              <span>(555) 123-4567</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;